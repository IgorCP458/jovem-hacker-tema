# nied-theme
Tema criado para o site do [Núcleo de Informática Aplicada à Educação](https://www.nied.unicamp.br/).

Para utilizar, basta clonar a pasta `nied-theme` dentro da pasta `/wp-content/themes/` da sua instalação do Wordpress.
