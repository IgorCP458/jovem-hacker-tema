<?php
// Template Name: Notícias
get_header();
?>

<?php include(TEMPLATEPATH . '/assets/includes/jumbotron-index.php'); ?>

<!-- noticias -->
<div class="pesquisa pagina-inicial" style="background: white;">
  <div class="container">
    <div class="row grid-row">
      <?php
         $args = array('category_name' => 'inicio', 'posts_per_page' => -1, 'post_status' => 'publish');
         $posts = get_posts($args);
         
         if($posts) : foreach ($posts as $post) : the_content();
      ?>
      <?php
         endforeach;
         endif;
      ?>
    </div>
  </div>
</div>
<?php get_footer(); ?>
